// TypeScript definitions for Qala SOS

export type UserRole = "citizen" | "worker" | "admin"

export interface User {
  id: string
  email: string
  full_name: string
  role: UserRole
  avatar_url?: string
  created_at: string
  updated_at: string
}

export type RequestStatus =
  | "pending"
  | "assigned"
  | "in_progress"
  | "resolved"
  | "rejected"

export type RequestCategory =
  | "water"
  | "electricity"
  | "roads"
  | "waste"
  | "safety"
  | "other"

export interface ServiceRequest {
  id: string
  citizen_id: string
  title: string
  description: string
  category: RequestCategory
  status: RequestStatus
  priority: "low" | "medium" | "high" | "critical"
  location: {
    lat: number
    lng: number
    address: string
  }
  photos: string[]
  assigned_worker_id?: string
  created_at: string
  updated_at: string
  resolved_at?: string
  sla_deadline?: string
}

export interface WorkerTask {
  id: string
  request_id: string
  worker_id: string
  status: "assigned" | "in_progress" | "completed"
  notes: string
  photos: string[]
  started_at?: string
  completed_at?: string
}

export interface SLAAlert {
  id: string
  request_id: string
  type: "warning" | "breach"
  message: string
  created_at: string
}

export interface HotspotData {
  lat: number
  lng: number
  intensity: number
  category: RequestCategory
}
