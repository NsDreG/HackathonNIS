"use client"

import type { HotspotData } from "@/types"

interface HotspotMapProps {
  data: HotspotData[]
}

export function HotspotMap({ data }: HotspotMapProps) {
  // TODO: Integrate with a real map library (e.g., Leaflet with heatmap plugin)
  return (
    <div className="rounded-lg border bg-muted/50 p-6">
      <div className="flex h-64 items-center justify-center text-muted-foreground">
        <div className="text-center">
          <p className="text-sm font-medium">Hotspot Heatmap</p>
          <p className="text-xs mt-1">
            {data.length} data point{data.length !== 1 ? "s" : ""} loaded
          </p>
          <p className="text-xs mt-2">
            Integrate a map library to display the heatmap
          </p>
        </div>
      </div>

      {/* Summary Fallback */}
      {data.length > 0 && (
        <div className="mt-4 grid grid-cols-2 gap-2">
          {Object.entries(
            data.reduce<Record<string, number>>((acc, point) => {
              acc[point.category] = (acc[point.category] || 0) + 1
              return acc
            }, {})
          ).map(([category, count]) => (
            <div key={category} className="rounded-md border bg-card p-2 text-center">
              <p className="text-xs font-medium text-card-foreground capitalize">{category}</p>
              <p className="text-lg font-bold text-card-foreground">{count}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
