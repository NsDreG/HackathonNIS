"use client"

import { AlertTriangle, AlertCircle } from "lucide-react"
import type { SLAAlert } from "@/types"

interface SLAAlertsProps {
  alerts: SLAAlert[]
}

export function SLAAlerts({ alerts }: SLAAlertsProps) {
  if (alerts.length === 0) {
    return (
      <div className="flex items-center justify-center rounded-lg border bg-muted/50 p-6 text-muted-foreground">
        <p className="text-sm">No SLA alerts at this time.</p>
      </div>
    )
  }

  return (
    <div className="space-y-2">
      {alerts.map((alert) => (
        <div
          key={alert.id}
          className={`flex items-start gap-3 rounded-lg border p-3 ${
            alert.type === "breach"
              ? "border-destructive bg-destructive/10"
              : "border-yellow-500 bg-yellow-500/10"
          }`}
        >
          {alert.type === "breach" ? (
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
          ) : (
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-yellow-600" />
          )}
          <div>
            <p
              className={`text-sm font-medium ${
                alert.type === "breach" ? "text-destructive" : "text-yellow-700"
              }`}
            >
              {alert.type === "breach" ? "SLA Breach" : "SLA Warning"}
            </p>
            <p className="text-xs text-muted-foreground mt-0.5">{alert.message}</p>
            <p className="text-xs text-muted-foreground mt-1">
              {new Date(alert.created_at).toLocaleString()}
            </p>
          </div>
        </div>
      ))}
    </div>
  )
}
