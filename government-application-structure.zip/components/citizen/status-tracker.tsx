"use client"

import type { RequestStatus } from "@/types"

interface StatusTrackerProps {
  status: RequestStatus
  createdAt: string
  updatedAt: string
  slaDeadline?: string
}

const statusSteps: { key: RequestStatus; label: string }[] = [
  { key: "pending", label: "Pending" },
  { key: "assigned", label: "Assigned" },
  { key: "in_progress", label: "In Progress" },
  { key: "resolved", label: "Resolved" },
]

function getStepIndex(status: RequestStatus): number {
  if (status === "rejected") return -1
  return statusSteps.findIndex((s) => s.key === status)
}

export function StatusTracker({
  status,
  createdAt,
  updatedAt,
  slaDeadline,
}: StatusTrackerProps) {
  const currentStep = getStepIndex(status)

  if (status === "rejected") {
    return (
      <div className="rounded-lg border border-destructive bg-destructive/10 p-4">
        <p className="text-sm font-medium text-destructive">Request Rejected</p>
        <p className="text-xs text-muted-foreground mt-1">
          Updated: {new Date(updatedAt).toLocaleDateString()}
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        {statusSteps.map((step, index) => (
          <div key={step.key} className="flex items-center gap-2">
            <div
              className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-medium ${
                index <= currentStep
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground"
              }`}
            >
              {index + 1}
            </div>
            <span
              className={`text-xs ${
                index <= currentStep ? "text-foreground font-medium" : "text-muted-foreground"
              }`}
            >
              {step.label}
            </span>
            {index < statusSteps.length - 1 && (
              <div
                className={`h-px w-6 ${
                  index < currentStep ? "bg-primary" : "bg-muted"
                }`}
              />
            )}
          </div>
        ))}
      </div>
      <div className="flex gap-4 text-xs text-muted-foreground">
        <span>Created: {new Date(createdAt).toLocaleDateString()}</span>
        {slaDeadline && (
          <span>SLA Deadline: {new Date(slaDeadline).toLocaleDateString()}</span>
        )}
      </div>
    </div>
  )
}
