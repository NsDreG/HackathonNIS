"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { ConfirmationModal } from "./confirmation-modal"
import type { RequestCategory } from "@/types"

const categories: { value: RequestCategory; label: string }[] = [
  { value: "water", label: "Water Supply" },
  { value: "electricity", label: "Electricity" },
  { value: "roads", label: "Roads & Infrastructure" },
  { value: "waste", label: "Waste Management" },
  { value: "safety", label: "Public Safety" },
  { value: "other", label: "Other" },
]

export function RequestForm() {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [category, setCategory] = useState<RequestCategory | "">("")
  const [address, setAddress] = useState("")
  const [showConfirmation, setShowConfirmation] = useState(false)
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setShowConfirmation(true)
  }

  async function handleConfirm() {
    setLoading(true)
    try {
      // TODO: Submit to Supabase
      console.log("Submitting request:", { title, description, category, address })
    } catch (error) {
      console.error("Submission failed:", error)
    } finally {
      setLoading(false)
      setShowConfirmation(false)
    }
  }

  return (
    <>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="title">Title</Label>
          <Input
            id="title"
            placeholder="Brief description of the issue"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="category">Category</Label>
          <Select
            value={category}
            onValueChange={(val) => setCategory(val as RequestCategory)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select a category" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((cat) => (
                <SelectItem key={cat.value} value={cat.value}>
                  {cat.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            placeholder="Provide more details about the issue..."
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="address">Location / Address</Label>
          <Input
            id="address"
            placeholder="Enter the address or location"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            required
          />
        </div>

        <Button type="submit" className="w-full" disabled={loading}>
          {loading ? "Submitting..." : "Submit Request"}
        </Button>
      </form>

      <ConfirmationModal
        open={showConfirmation}
        onClose={() => setShowConfirmation(false)}
        onConfirm={handleConfirm}
        title={title}
        category={category || "other"}
      />
    </>
  )
}
