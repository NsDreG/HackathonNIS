"use client"

import { AlertTriangle, CheckCircle, Clock, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { WorkerTask } from "@/types"

interface TaskMapProps {
  tasks: WorkerTask[]
}

export function TaskMap({ tasks }: TaskMapProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "assigned":
        return <Clock className="h-4 w-4 text-blue-500" />
      case "in_progress":
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      default:
        return <MapPin className="h-4 w-4" />
    }
  }

  return (
    <div className="space-y-3">
      <div className="rounded-lg border bg-muted/50 p-6">
        <div className="flex h-64 items-center justify-center text-muted-foreground">
          <div className="text-center">
            <MapPin className="mx-auto h-12 w-12 mb-2 opacity-20" />
            <p className="text-sm font-medium">Task Map View</p>
            <p className="text-xs mt-1">Map integration coming soon</p>
          </div>
        </div>
      </div>

      {/* Task List Fallback */}
      {tasks.length > 0 && (
        <div className="space-y-2">
          {tasks.map((task) => (
            <div
              key={task.id}
              className="flex items-start gap-3 rounded-lg border bg-card p-3"
            >
              <div className="mt-0.5">{getStatusIcon(task.status)}</div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-card-foreground capitalize">
                  {task.category}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                  {task.address}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {new Date(task.assigned_at).toLocaleDateString()}
                </p>
              </div>
              <Button size="sm" variant="outline">
                View
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
