"use client"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Upload, X } from "lucide-react"

interface PhotoUploaderProps {
  onUpload: (files: File[]) => void
  maxFiles?: number
}

export function PhotoUploader({ onUpload, maxFiles = 5 }: PhotoUploaderProps) {
  const [previews, setPreviews] = useState<string[]>([])
  const [files, setFiles] = useState<File[]>([])
  const inputRef = useRef<HTMLInputElement>(null)

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const selectedFiles = Array.from(e.target.files || [])
    const remaining = maxFiles - files.length
    const newFiles = selectedFiles.slice(0, remaining)

    const newPreviews = newFiles.map((file) => URL.createObjectURL(file))
    const updatedFiles = [...files, ...newFiles]
    const updatedPreviews = [...previews, ...newPreviews]

    setFiles(updatedFiles)
    setPreviews(updatedPreviews)
    onUpload(updatedFiles)
  }

  function removePhoto(index: number) {
    URL.revokeObjectURL(previews[index])
    const updatedFiles = files.filter((_, i) => i !== index)
    const updatedPreviews = previews.filter((_, i) => i !== index)
    setFiles(updatedFiles)
    setPreviews(updatedPreviews)
    onUpload(updatedFiles)
  }

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-3 gap-2">
        {previews.map((src, index) => (
          <div key={index} className="relative aspect-square rounded-md overflow-hidden border">
            <img src={src} alt={`Upload ${index + 1}`} className="h-full w-full object-cover" />
            <button
              type="button"
              onClick={() => removePhoto(index)}
              className="absolute right-1 top-1 rounded-full bg-background/80 p-1 hover:bg-background"
              aria-label={`Remove photo ${index + 1}`}
            >
              <X className="h-3 w-3" />
            </button>
          </div>
        ))}
      </div>

      {files.length < maxFiles && (
        <>
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            multiple
            onChange={handleFileChange}
            className="sr-only"
            aria-label="Upload photos"
          />
          <Button
            type="button"
            variant="outline"
            className="w-full"
            onClick={() => inputRef.current?.click()}
          >
            <Upload className="mr-2 h-4 w-4" />
            Upload Photos ({files.length}/{maxFiles})
          </Button>
        </>
      )}
    </div>
  )
}
