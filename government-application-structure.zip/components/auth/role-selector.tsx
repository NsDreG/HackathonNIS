"use client"

import { Button } from "@/components/ui/button"
import type { UserRole } from "@/types"

interface RoleSelectorProps {
  onSelect: (role: UserRole) => void
  selectedRole?: UserRole
}

const roles: { value: UserRole; label: string; description: string }[] = [
  { value: "citizen", label: "Citizen", description: "Submit and track service requests" },
  { value: "worker", label: "Field Worker", description: "Manage and resolve assigned tasks" },
  { value: "admin", label: "Administrator", description: "Oversee operations and analytics" },
]

export function RoleSelector({ onSelect, selectedRole }: RoleSelectorProps) {
  return (
    <div className="space-y-3">
      <p className="text-sm font-medium text-foreground">Select your role</p>
      <div className="grid gap-2">
        {roles.map((role) => (
          <Button
            key={role.value}
            variant={selectedRole === role.value ? "default" : "outline"}
            className="h-auto flex-col items-start p-4"
            onClick={() => onSelect(role.value)}
          >
            <span className="font-semibold">{role.label}</span>
            <span className="text-xs opacity-70">{role.description}</span>
          </Button>
        ))}
      </div>
    </div>
  )
}
