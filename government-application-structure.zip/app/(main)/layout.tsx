// Role-based auth guard layout
// TODO: Implement actual auth guard with Supabase session check

export default function MainLayout({
  children,
}: {
  children: React.ReactNode
}) {
  // TODO: Check user session and role
  // Redirect to login if not authenticated
  // Restrict access based on role

  return (
    <div className="min-h-screen bg-background">
      {children}
    </div>
  )
}
