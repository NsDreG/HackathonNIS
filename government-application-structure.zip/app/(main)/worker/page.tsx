import { TaskMap } from "@/components/worker/task-map"
import { PhotoUploader } from "@/components/worker/photo-uploader"

export default function WorkerDashboard() {
  // TODO: Fetch from Supabase
  const mockTasks = [
    {
      id: "1",
      category: "water",
      address: "123 Main St, Astana",
      latitude: 51.1694,
      longitude: 71.4495,
      status: "assigned",
      assigned_at: new Date().toISOString(),
      priority: "high" as const,
    },
    {
      id: "2",
      category: "electricity",
      address: "456 Park Ave, Astana",
      latitude: 51.1750,
      longitude: 71.4550,
      status: "in_progress",
      assigned_at: new Date().toISOString(),
      priority: "medium" as const,
    },
  ]

  return (
    <main className="container mx-auto p-6">
      <h1 className="text-2xl font-bold text-foreground mb-6">Worker Dashboard</h1>

      <div className="grid gap-6 md:grid-cols-3 mb-6">
        <div className="rounded-lg border bg-card p-6 text-card-foreground shadow-sm">
          <h3 className="text-sm font-medium text-muted-foreground">Assigned</h3>
          <p className="text-3xl font-bold mt-2">{mockTasks.filter(t => t.status === "assigned").length}</p>
        </div>
        <div className="rounded-lg border bg-card p-6 text-card-foreground shadow-sm">
          <h3 className="text-sm font-medium text-muted-foreground">In Progress</h3>
          <p className="text-3xl font-bold mt-2">{mockTasks.filter(t => t.status === "in_progress").length}</p>
        </div>
        <div className="rounded-lg border bg-card p-6 text-card-foreground shadow-sm">
          <h3 className="text-sm font-medium text-muted-foreground">Completed Today</h3>
          <p className="text-3xl font-bold mt-2">5</p>
        </div>
      </div>

      <div className="space-y-6">
        <div>
          <h2 className="text-lg font-semibold mb-3">Active Tasks</h2>
          <TaskMap tasks={mockTasks} />
        </div>

        <div className="rounded-lg border bg-card p-6 shadow-sm">
          <h2 className="text-lg font-semibold mb-3">Upload Task Photos</h2>
          <p className="text-sm text-muted-foreground mb-4">
            Upload before/after photos to document completed work
          </p>
          <PhotoUploader onUpload={(files) => console.log("Photos:", files)} />
        </div>
      </div>
    </main>
  )
}
