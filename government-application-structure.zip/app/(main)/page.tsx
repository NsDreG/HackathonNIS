import { redirect } from "next/navigation"

// Redirect logic based on user role
export default function MainPage() {
  // TODO: Get user role from session
  // For now redirect to citizen dashboard
  const userRole = "citizen" // Replace with actual role from auth

  switch (userRole) {
    case "admin":
      redirect("/admin")
    case "worker":
      redirect("/worker")
    case "citizen":
    default:
      redirect("/citizen")
  }
}
