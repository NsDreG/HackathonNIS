// Admin dashboard
import { HotspotMap } from "@/components/admin/hotspot-map"
import { SLAAlerts } from "@/components/admin/sla-alerts"

export default function AdminDashboard() {
  // TODO: Fetch from Supabase
  const mockAlerts = [
    {
      id: "1",
      type: "warning" as const,
      message: "Request #1234 approaching SLA deadline (4 hours remaining)",
      created_at: new Date().toISOString(),
    },
    {
      id: "2",
      type: "breach" as const,
      message: "Request #1122 has breached SLA deadline by 2 hours",
      created_at: new Date().toISOString(),
    },
  ]

  const mockHotspots = [
    { latitude: 51.1694, longitude: 71.4495, category: "water", count: 5 },
    { latitude: 51.1750, longitude: 71.4550, category: "electricity", count: 3 },
  ]

  return (
    <main className="container mx-auto p-6">
      <h1 className="text-2xl font-bold text-foreground mb-6">Admin Dashboard</h1>

      <div className="grid gap-4 md:grid-cols-3 mb-6">
        <div className="rounded-lg border bg-card p-6 text-card-foreground shadow-sm">
          <h3 className="text-sm font-medium text-muted-foreground">Total Requests</h3>
          <p className="text-3xl font-bold mt-2">247</p>
        </div>
        <div className="rounded-lg border bg-card p-6 text-card-foreground shadow-sm">
          <h3 className="text-sm font-medium text-muted-foreground">Pending</h3>
          <p className="text-3xl font-bold mt-2">42</p>
        </div>
        <div className="rounded-lg border bg-card p-6 text-card-foreground shadow-sm">
          <h3 className="text-sm font-medium text-muted-foreground">Avg Resolution</h3>
          <p className="text-3xl font-bold mt-2">18h</p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div>
          <h2 className="text-lg font-semibold mb-3">SLA Alerts</h2>
          <SLAAlerts alerts={mockAlerts} />
        </div>
        <div>
          <h2 className="text-lg font-semibold mb-3">Request Hotspots</h2>
          <HotspotMap data={mockHotspots} />
        </div>
      </div>
    </main>
  )
}
