import { RequestForm } from "@/components/citizen/request-form"
import Link from "next/link"

export default function SubmitRequestPage() {
  return (
    <main className="container mx-auto p-6 max-w-2xl">
      <div className="mb-6">
        <Link
          href="/citizen"
          className="text-sm text-muted-foreground hover:text-foreground"
        >
          ← Back to Dashboard
        </Link>
      </div>

      <div className="rounded-lg border bg-card p-6 shadow-sm">
        <h1 className="text-2xl font-bold text-card-foreground mb-2">
          Submit Service Request
        </h1>
        <p className="text-sm text-muted-foreground mb-6">
          Report an issue or request municipal services in your area.
        </p>

        <RequestForm />
      </div>
    </main>
  )
}
