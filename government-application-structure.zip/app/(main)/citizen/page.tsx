import Link from "next/link"
import { StatusTracker } from "@/components/citizen/status-tracker"
import { Button } from "@/components/ui/button"

export default function CitizenDashboard() {
  // TODO: Fetch from Supabase
  const mockRequests = [
    {
      id: "1",
      title: "Broken street light on Main St",
      category: "electricity" as const,
      status: "in_progress" as const,
      created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      updated_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
      sla_deadline: new Date(Date.now() + 22 * 60 * 60 * 1000).toISOString(),
    },
  ]

  return (
    <main className="container mx-auto p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-foreground">Citizen Dashboard</h1>
        <Link href="/citizen/submit">
          <Button>New Request</Button>
        </Link>
      </div>

      <div className="grid gap-4 md:grid-cols-3 mb-6">
        <div className="rounded-lg border bg-card p-6 text-card-foreground shadow-sm">
          <h3 className="text-sm font-medium text-muted-foreground">Total Requests</h3>
          <p className="text-3xl font-bold mt-2">12</p>
        </div>
        <div className="rounded-lg border bg-card p-6 text-card-foreground shadow-sm">
          <h3 className="text-sm font-medium text-muted-foreground">In Progress</h3>
          <p className="text-3xl font-bold mt-2">3</p>
        </div>
        <div className="rounded-lg border bg-card p-6 text-card-foreground shadow-sm">
          <h3 className="text-sm font-medium text-muted-foreground">Resolved</h3>
          <p className="text-3xl font-bold mt-2">9</p>
        </div>
      </div>

      <div className="space-y-6">
        <div>
          <h2 className="text-lg font-semibold mb-4">My Recent Requests</h2>
          {mockRequests.length > 0 ? (
            <div className="space-y-4">
              {mockRequests.map((request) => (
                <div
                  key={request.id}
                  className="rounded-lg border bg-card p-6 shadow-sm"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="font-semibold text-card-foreground">
                        {request.title}
                      </h3>
                      <p className="text-sm text-muted-foreground capitalize mt-1">
                        {request.category}
                      </p>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      #{request.id}
                    </span>
                  </div>
                  <StatusTracker
                    status={request.status}
                    createdAt={request.created_at}
                    updatedAt={request.updated_at}
                    slaDeadline={request.sla_deadline}
                  />
                </div>
              ))}
            </div>
          ) : (
            <div className="rounded-lg border bg-muted/50 p-12 text-center">
              <p className="text-muted-foreground mb-4">No requests yet</p>
              <Link href="/citizen/submit">
                <Button>Submit Your First Request</Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </main>
  )
}
