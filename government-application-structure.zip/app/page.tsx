import Link from "next/link"
import { Building2, HardHat, Shield, ArrowRight } from "lucide-react"

export default function Page() {
  return (
    <main className="flex min-h-screen flex-col">
      {/* Hero Section */}
      <div className="flex flex-1 flex-col items-center justify-center p-6 bg-gradient-to-b from-background to-muted/20">
        <div className="w-full max-w-4xl space-y-8 text-center">
          <div className="space-y-4">
            <h1 className="text-5xl font-bold tracking-tight text-foreground">
              Qala SOS
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
              Municipal Service Request Platform for Citizens, Workers, and Administrators
            </p>
          </div>

          <div className="grid gap-4 md:grid-cols-3 max-w-3xl mx-auto pt-8">
            {/* Citizen Portal */}
            <Link
              href="/citizen"
              className="group relative rounded-lg border bg-card p-6 text-card-foreground shadow-sm hover:shadow-md transition-all hover:border-primary"
            >
              <div className="flex flex-col items-center space-y-3">
                <div className="rounded-full bg-primary/10 p-3">
                  <Building2 className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-lg">Citizen Portal</h3>
                <p className="text-sm text-muted-foreground text-center">
                  Submit and track service requests
                </p>
                <ArrowRight className="h-4 w-4 text-primary opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </Link>

            {/* Worker Portal */}
            <Link
              href="/worker"
              className="group relative rounded-lg border bg-card p-6 text-card-foreground shadow-sm hover:shadow-md transition-all hover:border-primary"
            >
              <div className="flex flex-col items-center space-y-3">
                <div className="rounded-full bg-primary/10 p-3">
                  <HardHat className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-lg">Worker Portal</h3>
                <p className="text-sm text-muted-foreground text-center">
                  Manage assigned tasks
                </p>
                <ArrowRight className="h-4 w-4 text-primary opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </Link>

            {/* Admin Dashboard */}
            <Link
              href="/admin"
              className="group relative rounded-lg border bg-card p-6 text-card-foreground shadow-sm hover:shadow-md transition-all hover:border-primary"
            >
              <div className="flex flex-col items-center space-y-3">
                <div className="rounded-full bg-primary/10 p-3">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-lg">Admin Dashboard</h3>
                <p className="text-sm text-muted-foreground text-center">
                  Monitor and analyze operations
                </p>
                <ArrowRight className="h-4 w-4 text-primary opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </Link>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t py-6">
        <div className="container mx-auto px-6">
          <p className="text-center text-sm text-muted-foreground">
            Built with Next.js 16, React 19, and Supabase
          </p>
        </div>
      </footer>
    </main>
  )
}
