-- Trigger to set SLA deadline when request is created

CREATE OR REPLACE FUNCTION public.set_sla_deadline()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  -- Set SLA deadline to 24 hours from creation for urgent, 48 hours for others
  IF NEW.priority = 'urgent' THEN
    NEW.sla_deadline := NEW.created_at + INTERVAL '24 hours';
  ELSIF NEW.priority = 'high' THEN
    NEW.sla_deadline := NEW.created_at + INTERVAL '48 hours';
  ELSE
    NEW.sla_deadline := NEW.created_at + INTERVAL '72 hours';
  END IF;
  
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS set_request_sla_deadline ON public.service_requests;

CREATE TRIGGER set_request_sla_deadline
  BEFORE INSERT ON public.service_requests
  FOR EACH ROW
  EXECUTE FUNCTION public.set_sla_deadline();

-- Function to check for SLA violations
CREATE OR REPLACE FUNCTION public.check_sla_violations()
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  -- Create warning alerts for requests approaching SLA deadline (4 hours left)
  INSERT INTO public.sla_alerts (request_id, type, message)
  SELECT 
    id,
    'warning',
    'Request #' || SUBSTRING(id::TEXT, 1, 8) || ' approaching SLA deadline (4 hours remaining)'
  FROM public.service_requests
  WHERE 
    status NOT IN ('resolved', 'closed', 'rejected')
    AND sla_deadline - NOW() <= INTERVAL '4 hours'
    AND sla_deadline - NOW() > INTERVAL '0 hours'
    AND NOT EXISTS (
      SELECT 1 FROM public.sla_alerts 
      WHERE request_id = service_requests.id 
      AND type = 'warning'
      AND created_at > NOW() - INTERVAL '6 hours'
    );

  -- Create breach alerts for requests past SLA deadline
  INSERT INTO public.sla_alerts (request_id, type, message)
  SELECT 
    id,
    'breach',
    'Request #' || SUBSTRING(id::TEXT, 1, 8) || ' has breached SLA deadline'
  FROM public.service_requests
  WHERE 
    status NOT IN ('resolved', 'closed', 'rejected')
    AND sla_deadline < NOW()
    AND NOT EXISTS (
      SELECT 1 FROM public.sla_alerts 
      WHERE request_id = service_requests.id 
      AND type = 'breach'
      AND created_at > NOW() - INTERVAL '24 hours'
    );
END;
$$;
