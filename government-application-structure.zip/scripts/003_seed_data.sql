-- Seed data for Qala SOS (optional - for testing)
-- This creates some sample requests and data

-- Note: This assumes you have test users created
-- You can skip this file if you want to start with an empty database

-- Insert sample service requests (only if there are existing users)
-- This is commented out by default to avoid errors
-- Uncomment and replace user IDs with actual IDs from your auth.users table

/*
insert into public.service_requests (
  citizen_id,
  category,
  title,
  description,
  status,
  priority,
  address,
  latitude,
  longitude
) values
(
  'YOUR_USER_ID_HERE',
  'lighting',
  'Broken street light on Main Street',
  'The street light at the corner of Main St and 5th Ave has been out for 3 days',
  'submitted',
  'high',
  'Main St & 5th Ave, Astana',
  51.1694,
  71.4495
),
(
  'YOUR_USER_ID_HERE',
  'roads',
  'Pothole on Park Avenue',
  'Large pothole causing traffic issues near the city center',
  'submitted',
  'medium',
  'Park Ave, Astana',
  51.1750,
  71.4550
);
*/

-- Create a view for admins to see SLA breaches
create or replace view public.sla_breaches as
select
  sr.id,
  sr.title,
  sr.category,
  sr.status,
  sr.created_at,
  sr.sla_deadline,
  extract(epoch from (now() - sr.sla_deadline)) / 3600 as hours_overdue,
  p.full_name as citizen_name,
  p.email as citizen_email
from public.service_requests sr
join public.profiles p on sr.citizen_id = p.id
where sr.sla_deadline < now()
  and sr.status not in ('resolved', 'closed')
order by sr.sla_deadline asc;

-- Grant access to the view for admins
grant select on public.sla_breaches to authenticated;
