-- Qala SOS Database Schema
-- Create all tables for the municipal service request platform

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- Service Request Categories enum
create type service_category as enum (
  'water',
  'electricity',
  'roads',
  'waste',
  'parks',
  'lighting',
  'other'
);

-- Request Status enum
create type request_status as enum (
  'submitted',
  'assigned',
  'in_progress',
  'resolved',
  'closed',
  'rejected'
);

-- User Roles enum
create type user_role as enum (
  'citizen',
  'worker',
  'admin'
);

-- Priority levels
create type priority_level as enum (
  'low',
  'medium',
  'high',
  'urgent'
);

-- Profiles table (extends auth.users)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique not null,
  full_name text,
  phone text,
  role user_role not null default 'citizen',
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Service Requests table
create table if not exists public.service_requests (
  id uuid primary key default uuid_generate_v4(),
  citizen_id uuid not null references public.profiles(id) on delete cascade,
  category service_category not null,
  title text not null,
  description text not null,
  status request_status not null default 'submitted',
  priority priority_level default 'medium',
  
  -- Location
  address text not null,
  latitude numeric(10, 8) not null,
  longitude numeric(11, 8) not null,
  
  -- Media
  citizen_photo_url text,
  worker_photo_before_url text,
  worker_photo_after_url text,
  
  -- Assignment
  assigned_worker_id uuid references public.profiles(id) on delete set null,
  assigned_at timestamp with time zone,
  
  -- SLA tracking
  sla_deadline timestamp with time zone,
  resolved_at timestamp with time zone,
  
  -- Timestamps
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Comments table
create table if not exists public.request_comments (
  id uuid primary key default uuid_generate_v4(),
  request_id uuid not null references public.service_requests(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  comment text not null,
  created_at timestamp with time zone default now()
);

-- Notifications table
create table if not exists public.notifications (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  request_id uuid references public.service_requests(id) on delete cascade,
  type text not null,
  message text not null,
  read boolean default false,
  created_at timestamp with time zone default now()
);

-- Create indexes for better query performance
create index if not exists idx_service_requests_citizen_id on public.service_requests(citizen_id);
create index if not exists idx_service_requests_status on public.service_requests(status);
create index if not exists idx_service_requests_assigned_worker on public.service_requests(assigned_worker_id);
create index if not exists idx_service_requests_created_at on public.service_requests(created_at desc);
create index if not exists idx_notifications_user_id on public.notifications(user_id);
create index if not exists idx_notifications_read on public.notifications(read);

-- Enable Row Level Security
alter table public.profiles enable row level security;
alter table public.service_requests enable row level security;
alter table public.request_comments enable row level security;
alter table public.notifications enable row level security;

-- RLS Policies for profiles
create policy "Users can view their own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Users can update their own profile"
  on public.profiles for update
  using (auth.uid() = id);

create policy "Workers and admins can view all profiles"
  on public.profiles for select
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and role in ('worker', 'admin')
    )
  );

-- RLS Policies for service_requests
create policy "Citizens can view their own requests"
  on public.service_requests for select
  using (citizen_id = auth.uid());

create policy "Citizens can create requests"
  on public.service_requests for insert
  with check (citizen_id = auth.uid());

create policy "Workers can view assigned requests"
  on public.service_requests for select
  using (
    assigned_worker_id = auth.uid() or
    exists (
      select 1 from public.profiles
      where id = auth.uid() and role in ('worker', 'admin')
    )
  );

create policy "Workers can update assigned requests"
  on public.service_requests for update
  using (
    assigned_worker_id = auth.uid() or
    exists (
      select 1 from public.profiles
      where id = auth.uid() and role = 'admin'
    )
  );

create policy "Admins can do everything with requests"
  on public.service_requests for all
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and role = 'admin'
    )
  );

-- RLS Policies for request_comments
create policy "Users can view comments on their requests"
  on public.request_comments for select
  using (
    exists (
      select 1 from public.service_requests
      where id = request_id and (
        citizen_id = auth.uid() or
        assigned_worker_id = auth.uid() or
        exists (
          select 1 from public.profiles
          where profiles.id = auth.uid() and role = 'admin'
        )
      )
    )
  );

create policy "Users can create comments on accessible requests"
  on public.request_comments for insert
  with check (
    user_id = auth.uid() and
    exists (
      select 1 from public.service_requests
      where id = request_id and (
        citizen_id = auth.uid() or
        assigned_worker_id = auth.uid() or
        exists (
          select 1 from public.profiles
          where profiles.id = auth.uid() and role = 'admin'
        )
      )
    )
  );

-- RLS Policies for notifications
create policy "Users can view their own notifications"
  on public.notifications for select
  using (user_id = auth.uid());

create policy "Users can update their own notifications"
  on public.notifications for update
  using (user_id = auth.uid());

-- Function to automatically set SLA deadline (24 hours from creation)
create or replace function set_sla_deadline()
returns trigger as $$
begin
  if new.sla_deadline is null then
    new.sla_deadline := new.created_at + interval '24 hours';
  end if;
  return new;
end;
$$ language plpgsql;

create trigger set_sla_deadline_trigger
  before insert on public.service_requests
  for each row
  execute function set_sla_deadline();

-- Function to update updated_at timestamp
create or replace function update_updated_at()
returns trigger as $$
begin
  new.updated_at := now();
  return new;
end;
$$ language plpgsql;

create trigger update_profiles_updated_at
  before update on public.profiles
  for each row
  execute function update_updated_at();

create trigger update_service_requests_updated_at
  before update on public.service_requests
  for each row
  execute function update_updated_at();
